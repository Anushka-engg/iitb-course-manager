// App.js
import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import './App.css';
import CourseList from './components/CourseList';
import CreateCourse from './components/CreateCourse';
import CreateInstance from './components/CreateInstance';
import InstanceList from './components/InstanceList';

function App() {
  return (
    <Router>
      <div className="App">
        <nav className="navbar">
          <div className="nav-container">
            <h1>IIT Bombay Course Management</h1>
            <div className="nav-links">
              <Link to="/" className="nav-link">Courses</Link>
              <Link to="/create-course" className="nav-link">Create Course</Link>
              <Link to="/create-instance" className="nav-link">Create Instance</Link>
              <Link to="/instances" className="nav-link">Instances</Link>
            </div>
          </div>
        </nav>

        <main className="main-content">
          <Routes>
            <Route path="/" element={<CourseList />} />
            <Route path="/create-course" element={<CreateCourse />} />
            <Route path="/create-instance" element={<CreateInstance />} />
            <Route path="/instances" element={<InstanceList />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;

// components/CourseList.js
import React, { useState, useEffect } from 'react';
import { courseService } from '../services/courseService';

const CourseList = () => {
  const [courses, setCourses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    loadCourses();
  }, []);

  const loadCourses = async () => {
    try {
      setLoading(true);
      const data = await courseService.getAllCourses();
      setCourses(data);
    } catch (err) {
      setError('Failed to load courses');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (courseId) => {
    if (window.confirm('Are you sure you want to delete this course?')) {
      try {
        await courseService.deleteCourse(courseId);
        loadCourses();
      } catch (err) {
        alert(err.message || 'Failed to delete course');
      }
    }
  };

  if (loading) return <div className="loading">Loading courses...</div>;
  if (error) return <div className="error">{error}</div>;

  return (
    <div className="course-list">
      <h2>Course List</h2>
      {courses.length === 0 ? (
        <p>No courses available.</p>
      ) : (
        <div className="course-grid">
          {courses.map(course => (
            <div key={course.id} className="course-card">
              <h3>{course.title}</h3>
              <p><strong>Course ID:</strong> {course.courseId}</p>
              <p><strong>Description:</strong> {course.description}</p>
              {course.prerequisites && course.prerequisites.length > 0 && (
                <div className="prerequisites">
                  <strong>Prerequisites:</strong>
                  <ul>
                    {course.prerequisites.map(prereq => (
                      <li key={prereq.id}>{prereq.courseId} - {prereq.title}</li>
                    ))}
                  </ul>
                </div>
              )}
              <button 
                onClick={() => handleDelete(course.courseId)}
                className="delete-btn"
              >
                Delete Course
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default CourseList;

// components/CreateCourse.js
import React, { useState, useEffect } from 'react';
import { courseService } from '../services/courseService';

const CreateCourse = () => {
  const [formData, setFormData] = useState({
    title: '',
    courseId: '',
    description: '',
    prerequisites: []
  });
  const [availableCourses, setAvailableCourses] = useState([]);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');

  useEffect(() => {
    loadAvailableCourses();
  }, []);

  const loadAvailableCourses = async () => {
    try {
      const courses = await courseService.getAllCourses();
      setAvailableCourses(courses);
    } catch (err) {
      console.error('Failed to load courses:', err);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handlePrerequisiteChange = (e) => {
    const selectedOptions = Array.from(e.target.selectedOptions, option => option.value);
    setFormData(prev => ({
      ...prev,
      prerequisites: selectedOptions
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setMessage('');
    
    try {
      await courseService.createCourse(formData);
      setMessage('Course created successfully!');
      setFormData({
        title: '',
        courseId: '',
        description: '',
        prerequisites: []
      });
      loadAvailableCourses();
    } catch (err) {
      setMessage(`Error: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="create-course">
      <h2>Create New Course</h2>
      <form onSubmit={handleSubmit} className="course-form">
        <div className="form-group">
          <label htmlFor="title">Course Title:</label>
          <input
            type="text"
            id="title"
            name="title"
            value={formData.title}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="courseId">Course ID:</label>
          <input
            type="text"
            id="courseId"
            name="courseId"
            value={formData.courseId}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="description">Description:</label>
          <textarea
            id="description"
            name="description"
            value={formData.description}
            onChange={handleChange}
            rows="4"
          />
        </div>

        <div className="form-group">
          <label htmlFor="prerequisites">Prerequisites:</label>
          <select
            id="prerequisites"
            multiple
            value={formData.prerequisites}
            onChange={handlePrerequisiteChange}
            className="prerequisite-select"
          >
            {availableCourses.map(course => (
              <option key={course.id} value={course.courseId}>
                {course.courseId} - {course.title}
              </option>
            ))}
          </select>
          <small>Hold Ctrl/Cmd to select multiple prerequisites</small>
        </div>

        <button type="submit" disabled={loading} className="submit-btn">
          {loading ? 'Creating...' : 'Create Course'}
        </button>
      </form>

      {message && (
        <div className={`message ${message.startsWith('Error') ? 'error' : 'success'}`}>
          {message}
        </div>
      )}
    </div>
  );
};

export default CreateCourse;

// components/CreateInstance.js
import React, { useState, useEffect } from 'react';
import { courseService } from '../services/courseService';

const CreateInstance = () => {
  const [formData, setFormData] = useState({
    courseId: '',
    year: new Date().getFullYear(),
    semester: 1
  });
  const [availableCourses, setAvailableCourses] = useState([]);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');

  useEffect(() => {
    loadAvailableCourses();
  }, []);

  const loadAvailableCourses = async () => {
    try {
      const courses = await courseService.getAllCourses();
      setAvailableCourses(courses);
    } catch (err) {
      console.error('Failed to load courses:', err);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: name === 'year' || name === 'semester' ? parseInt(value) : value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setMessage('');
    
    try {
      await courseService.createCourseInstance(formData);
      setMessage('Course instance created successfully!');
      setFormData({
        courseId: '',
        year: new Date().getFullYear(),
        semester: 1
      });
    } catch (err) {
      setMessage(`Error: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="create-instance">
      <h2>Create Course Instance</h2>
      <form onSubmit={handleSubmit} className="instance-form">
        <div className="form-group">
          <label htmlFor="courseId">Select Course:</label>
          <select
            id="courseId"
            name="courseId"
            value={formData.courseId}
            onChange={handleChange}
            required
          >
            <option value="">Select a course</option>
            {availableCourses.map(course => (
              <option key={course.id} value={course.courseId}>
                {course.courseId} - {course.title}
              </option>
            ))}
          </select>
        </div>

        <div className="form-group">
          <label htmlFor="year">Year:</label>
          <input
            type="number"
            id="year"
            name="year"
            value={formData.year}
            onChange={handleChange}
            min="2000"
            max="2100"
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="semester">Semester:</label>
          <select
            id="semester"
            name="semester"
            value={formData.semester}
            onChange={handleChange}
            required
          >
            <option value={1}>Semester 1</option>
            <option value={2}>Semester 2</option>
          </select>
        </div>

        <button type="submit" disabled={loading} className="submit-btn">
          {loading ? 'Creating...' : 'Create Instance'}
        </button>
      </form>

      {message && (
        <div className={`message ${message.startsWith('Error') ? 'error' : 'success'}`}>
          {message}
        </div>
      )}
    </div>
  );
};

export default CreateInstance;

// components/InstanceList.js
import React, { useState, useEffect } from 'react';
import { courseService } from '../services/courseService';

const InstanceList = () => {
  const [instances, setInstances] = useState([]);
  const [filters, setFilters] = useState({
    year: new Date().getFullYear(),
    semester: 1
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    loadInstances();
  }, [filters]);

  const loadInstances = async () => {
    try {
      setLoading(true);
      const data = await courseService.getCourseInstancesBySemester(filters.year, filters.semester);
      setInstances(data);
    } catch (err) {
      setError('Failed to load course instances');
    } finally {
      setLoading(false);
    }
  };

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters(prev => ({
      ...prev,
      [name]: name === 'year' || name === 'semester' ? parseInt(value) : value
    }));
  };

  const handleDelete = async (year, semester, courseId) => {
    if (window.confirm('Are you sure you want to delete this course instance?')) {
      try {
        await courseService.deleteCourseInstance(year, semester, courseId);
        loadInstances();
      } catch (err) {
        alert(err.message || 'Failed to delete course instance');
      }
    }
  };

  return (
    <div className="instance-list">
      <h2>Course Instances</h2>
      
      <div className="filters">
        <div className="filter-group">
          <label htmlFor="year">Year:</label>
          <input
            type="number"
            id="year"
            name="year"
            value={filters.year}
            onChange={handleFilterChange}
            min="2000"
            max="2100"
          />
        </div>
        <div className="filter-group">
          <label htmlFor="semester">Semester:</label>
          <select
            id="semester"
            name="semester"
            value={filters.semester}
            onChange={handleFilterChange}
          >
            <option value={1}>Semester 1</option>
            <option value={2}>Semester 2</option>
          </select>
        </div>
      </div>

      {loading && <div className="loading">Loading instances...</div>}
      {error && <div className="error">{error}</div>}

      {!loading && !error && (
        <div className="instances-grid">
          {instances.length === 0 ? (
            <p>No course instances found for the selected year and semester.</p>
          ) : (
            instances.map(instance => (
              <div key={instance.id} className="instance-card">
                <h3>{instance.course.title}</h3>
                <p><strong>Course ID:</strong> {instance.course.courseId}</p>
                <p><strong>Year:</strong> {instance.year}</p>
                <p><strong>Semester:</strong> {instance.semester}</p>
                <p><strong>Description:</strong> {instance.course.description}</p>
                {instance.course.prerequisites && instance.course.prerequisites.length > 0 && (
                  <div className="prerequisites">
                    <strong>Prerequisites:</strong>
                    <ul>
                      {instance.course.prerequisites.map(prereq => (
                        <li key={prereq.id}>{prereq.courseId} - {prereq.title}</li>
                      ))}
                    </ul>
                  </div>
                )}
                <button 
                  onClick={() => handleDelete(instance.year, instance.semester, instance.course.courseId)}
                  className="delete-btn"
                >
                  Delete Instance
                </button>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
};

export default InstanceList;

// services/courseService.js
const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:8080/api';

class CourseService {
  async getAllCourses() {
    const response = await fetch(`${API_BASE_URL}/courses`);
    if (!response.ok) {
      throw new Error('Failed to fetch courses');
    }
    return response.json();
  }

  async getCourse(courseId) {
    const response = await fetch(`${API_BASE_URL}/courses/${courseId}`);
    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(errorText || 'Failed to fetch course');
    }
    return response.json();
  }

  async createCourse(courseData) {
    const response = await fetch(`${API_BASE_URL}/courses`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(courseData),
    });
    
    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(errorText || 'Failed to create course');
    }
    return response.json();
  }

  async deleteCourse(courseId) {
    const response = await fetch(`${API_BASE_URL}/courses/${courseId}`, {
      method: 'DELETE',
    });
    
    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(errorText || 'Failed to delete course');
    }
  }

  async createCourseInstance(instanceData) {
    const response = await fetch(`${API_BASE_URL}/instances`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(instanceData),
    });
    
    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(errorText || 'Failed to create course instance');
    }
    return response.json();
  }

  async getCourseInstancesBySemester(year, semester) {
    const response = await fetch(`${API_BASE_URL}/instances/${year}/${semester}`);
    if (!response.ok) {
      throw new Error('Failed to fetch course instances');
    }
    return response.json();
  }

  async getCourseInstance(year, semester, courseId) {
    const response = await fetch(`${API_BASE_URL}/instances/${year}/${semester}/${courseId}`);
    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(errorText || 'Failed to fetch course instance');
    }
    return response.json();
  }

  async deleteCourseInstance(year, semester, courseId) {
    const response = await fetch(`${API_BASE_URL}/instances/${year}/${semester}/${courseId}`, {
      method: 'DELETE',
    });
    
    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(errorText || 'Failed to delete course instance');
    }
  }
}

export const courseService = new CourseService();