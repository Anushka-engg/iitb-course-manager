// App.js
import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import './App.css';
import CourseList from './components/CourseList';
import CreateCourse from './components/CreateCourse';
import CreateInstance from './components/CreateInstance';
import InstanceList from './components/InstanceList';

function App() {
  return (
    <Router>
      <div className="App">
        <nav className="navbar">
          <div className="nav-container">
            <h1>IIT Bombay Course Management</h1>
            <div className="nav-links">
              <Link to="/" className="nav-link">Courses</Link>
              <Link to="/create-course" className="nav-link">Create Course</Link>
              <Link to="/create-instance" className="nav-link">Create Instance</Link>
              <Link to="/instances" className="nav-link">Instances</Link>
            </div>
          </div>
        </nav>

        <main className="main-content">
          <Routes>
            <Route path="/" element={<CourseList />} />
            <Route path="/create-course" element={<CreateCourse />} />
            <Route path="/create-instance" element={<CreateInstance />} />
            <Route path="/instances" element={<InstanceList />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;

// components/CourseList.js
import React, { useState, useEffect } from 'react';
import { courseService } from '../services/courseService';

const CourseList = () => {
  const [courses, setCourses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    loadCourses();
  }, []);

  const loadCourses = async () => {
    try {
      setLoading(true);
      const data = await courseService.getAllCourses();
      setCourses(data);
    } catch (err) {
      setError('Failed to load courses');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (courseId) => {
    if (window.confirm('Are you sure you want to delete this course?')) {
      try {
        await courseService.deleteCourse(courseId);
        loadCourses();
      } catch (err) {
        alert(err.message || 'Failed to delete course');
      }
    }
  };

  if (loading) return <div className="loading">Loading courses...</div>;
  if (error) return <div className="error">{error}</div>;

  return (
    <div className="course-list">
      <h2>Course List</h2>
      {courses.length === 0 ? (
        <p>No courses available.</p>
      ) : (
        <div className="course-grid">
          {courses.map(course => (
            <div key={course.id} className="course-card">
              <h3>{course.title}</h3>
              <p><strong>Course ID:</strong> {course.courseId}</p>
              <p><strong>Description:</strong> {course.description}</p>
              {course.prerequisites && course.prerequisites.length > 0 && (
                <div className="prerequisites">
                  <strong>Prerequisites:</strong>
                  <ul>
                    {course.prerequisites.map(prereq => (
                      <li key={prereq.id}>{prereq.courseId} - {prereq.title}</li>
                    ))}
                  </ul>
                </div>
              )}
              <button 
                onClick={() => handleDelete(course.courseId)}
                className="delete-btn"
              >
                Delete Course
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default CourseList;

// components/CreateCourse.js
import React, { useState, useEffect } from 'react';
import { courseService } from '../services/courseService';

const CreateCourse = () => {
  const [formData, setFormData] = useState({
    title: '',
    courseId: '',
    description: '',
    prerequisites: []
  });
  const [availableCourses, setAvailableCourses] = useState([]);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');

  useEffect(() => {
    loadAvailableCourses();
  }, []);

  const loadAvailableCourses = async () => {
    try {
      const courses = await courseService.getAllCourses();
      setAvailableCourses(courses);
    } catch (err) {
      console.error('Failed to load courses:', err);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value